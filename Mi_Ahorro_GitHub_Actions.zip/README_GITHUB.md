# Mi Ahorro — compilación automática

## Cómo generar la APK desde GitHub

1. Crea un repositorio nuevo en GitHub, por ejemplo `mi-ahorro`.
2. Sube **todo el contenido de esta carpeta**, incluyendo `.github/workflows/build-apk.yml`.
3. Ve a **Actions**.
4. Abre **Build Mi Ahorro APK**.
5. Pulsa **Run workflow** si no se inició automáticamente.
6. Cuando termine correctamente, abre la ejecución y busca **Artifacts**.
7. Descarga `Mi-Ahorro-APK`.
8. Dentro encontrarás `app-debug.apk`.

No necesitas instalar Android Studio en tu teléfono.

## Nota
Esta compilación genera una APK debug para uso personal. Para distribuirla públicamente en Google Play conviene crear una firma/release específica.
