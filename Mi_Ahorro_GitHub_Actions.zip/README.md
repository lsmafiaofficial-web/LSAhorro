# Mi Ahorro — Android v1

Proyecto Android listo para abrir en Android Studio.

Incluye:
- Inicio financiero
- Ingresos, gastos y ahorros
- Metas con fecha límite
- Proyección mensual/quincenal
- Estadísticas básicas
- Calculadora de preguntas financieras
- Datos guardados localmente mediante localStorage

## Compilar
1. Abrir esta carpeta en Android Studio.
2. Esperar a que Gradle sincronice.
3. Build > Build APK(s).
4. El APK debug aparecerá en:
   app/build/outputs/apk/debug/app-debug.apk

El proyecto requiere Android SDK 35 y conexión a Internet la primera vez para descargar dependencias Gradle/AndroidX.
